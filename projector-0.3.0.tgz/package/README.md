<div align="center">

# Projector

</div>

This is a recreational coding physics sim project that runs on canvas in the browser. 

```
npm install
npm run dev
```

`npm run dev` starts Vite. Open the printed URL for the demo gallery; demos reload when you save a file.

| Script | What it does |
| --- | --- |
| `npm run dev` | Dev server with the demo gallery |
| `npm test` / `npm run test:watch` | Unit tests and work budgets (Vitest) |
| `npm run typecheck` | Type-checks the library, demos, tests and benchmarks |
| `npm run build` | Library build: `dist/projector.js` (ESM) and `dist/types` |
| `npm run build:demos` / `npm run preview` | Static build of the demo site in `dist-demos` / serve it |
| `npm run check` | Typecheck, tests and build in one go |
| `npm run perf` | Times every demo against `perf/baseline.json` (see [Performance](#performance)) |
| `npm run perf:baseline` / `perf:rebaseline` | Records baselines for new scenarios / re-records all |

## Using Projector in your own project

Projector ships as one ES module with type declarations (`dist/`) and has no runtime dependencies. Any
bundler works; with Vite:

```
npm create vite@latest my-game -- --template vanilla-ts
cd my-game
npm install ../Projector/projector-0.2.0.tgz
```

Ways to install it:

| From | How |
| --- | --- |
| A package file | `npm pack` here (builds and writes `projector-0.2.0.tgz`), then `npm install <path to the .tgz>` there |
| GitHub | `npm install github:ChrisDrae/Projector#feature/engine`: npm clones the branch and builds it |
| This folder, while changing both | `npm install ../Projector` links it; run `npm run build` here after each change |

A starting point for a game: a ball you roll with the arrow keys, carrying its own light, and crates falling
from the sky. The canvas fills whatever size CSS gives it (e.g. `width: 100vw; height: 100vh`).

```ts
import { DirectionalLight, Ground, HemisphereLight, PointLight, RigidBox, RigidSphere, SimObject, Simulation, type Vec3 } from "projector";

/** The player: a ball pushed by the arrow keys, carrying its own light. */
class Player extends RigidSphere {
  constructor(position: Vec3) {
    super(0.25, { position, mass: 2, material: { color: "#f1eeee", shading: "smooth", specular: 0.6 } });
    this.addLight(new PointLight({ x: 0, y: 0.6, z: 0 }, { color: "#ffb26b", intensity: 1.5, distance: 4 }));
  }

  override update(): void {
    const kb = this.sim?.keyboard;
    if (!kb) return;
    this.applyForce({ x: kb.axis("ArrowLeft", "ArrowRight") * 6, y: 0, z: kb.axis("ArrowDown", "ArrowUp") * 6 });
  }
}

/** Drops a crate every second, ten in all. */
class CrateSpawner extends SimObject {
  private timer = 0;
  private spawned = 0;

  override update(dt: number): void {
    this.timer += dt;
    if (this.timer < 1 || this.spawned >= 10) return;
    this.timer = 0;
    this.spawned++;
    this.sim!.add(new RigidBox(0.4, { position: { x: Math.random() * 4 - 2, y: 4, z: Math.random() * 4 - 2 } }));
  }
}

const game = new Simulation({
  canvas: document.querySelector("canvas")!,
  scene: { background: "#1d2026" },
  orbit: { button: 2, distance: 9, pitch: -0.5 },
});
game.scene.lights = [
  new HemisphereLight("#9db4ff", "#3b3127", 0.35),
  new DirectionalLight({ x: -0.4, y: -1, z: 0.3 }, 0.7, { castShadow: true }),
];
game.add(new Ground({ style: "plane", size: 10, color: "#4b4f58", opacity: 1 }));
game.add(new Player({ x: 0, y: 0.25, z: 0 }));
game.add(new CrateSpawner());
game.start();
```

The demos in `demos/` are fuller examples: each `setup.ts` builds a scene from these pieces.

## Demos

- **Cube container**: thousands of spheres inside a box you can spin and throw around. Switch the broadphase
  between accurate and sandbox mode and stress it with "Pile 2000".
- **Gravitation**: n-body attraction with collisions, a disk of bodies orbiting a heavy core. Optionally lit
  by the core.
- **Cloth**: 30×30 distance-constrained particles in Perlin noise wind, draping over a sphere.
- **Flow field**: 4000 particles in an evolving curl-noise field.
- **Rigid bodies**: a box pyramid, capsules and balls; click to throw things, pour particles on the pile.
- **Lighting**: colored point and spot lights, smooth vs flat shading, highlights, sprites, shadows and fog.

Every demo page takes `?bench` (or `?bench=900`): it runs a fixed number of frames and logs the frame,
update and render times. `demo` on the browser console is the running simulation.

## Building a simulation

```ts
import { DirectionalLight, Ground, HemisphereLight, ParticleGroup, RigidBox, RigidSphere, Simulation } from "projector";

const sim = new Simulation({
  canvas: document.querySelector("canvas")!,
  scene: { background: "#1d2026" },
  orbit: { target: { x: 0, y: 0.5, z: 0 }, distance: 4, pitch: -0.3 },
});
sim.scene.lights = [
  new HemisphereLight("#9db4ff", "#3b3127", 0.4),
  new DirectionalLight({ x: -0.5, y: -1, z: 0.3 }, 0.8, { castShadow: true }),
];

sim.add(new Ground({ style: "plane", size: 8, color: "#4b4f58", opacity: 1 }));
for (let k = 0; k < 5; k++) sim.add(new RigidBox(0.4, { position: { x: 0, y: 0.2 + k * 0.41, z: 0 } }));
sim.add(new RigidSphere(0.2, { position: { x: -2, y: 0.2, z: 0 }, velocity: { x: 6, y: 0, z: 0 } }));

const sand = sim.add(new ParticleGroup({ radius: 0.03, shading: "lit", color: "#e0a23a" }));
sand.spawn(500, (_, p) => {
  p.x = Math.random() - 0.5;
  p.y = 3 + Math.random();
  p.z = Math.random() - 0.5;
});
sim.start();
```

`Simulation` owns the physics `World`, the `Scene`, the camera (with orbit controls), the renderer and the
frame loop. Every frame it runs:

1. `onUpdate` listeners, then `update(dt)` on every object
2. `world.step(dt)` in fixed 1/120 s steps; each step first runs `onFixedUpdate` listeners and `fixedUpdate(dt)`
3. `sync()` on every object (physics state into transforms and meshes), then world matrices
4. render, then `onAfterRender` listeners

Without a canvas it runs headless (tests, benchmarks, Node): call `sim.frame(dt)` yourself. `sim.pick(x, y)`
returns what is under the pointer (particles, rigid bodies, colliders).

### Built-in objects

| Object | What it is |
| --- | --- |
| `RigidBox`, `RigidSphere`, `RigidCapsule` (`RigidObject`) | A rigid body and its mesh, kept in sync |
| `ParticleGroup` | Particles or spheres in the world's typed arrays, drawn as one cloud; flat, lit or sprite shaded |
| `Container` | A kinematic box that keeps bodies inside; move and spin it to throw them around |
| `Ground` | A floor: physics plane plus a drawn grid or plane that receives shadows |
| `StaticSphere` | A fixed ball to bounce off or drape over |
| `Cloth` | A sheet of particles held by distance constraints, drawn as a mesh |
| `VelocityTrails` | Motion streaks behind particles |
| `MeshObject` | Any mesh in the scene graph, without physics |

### Writing your own objects

Extend `SimObject`. An object has a transform relative to its parent, children, and resources it owns: scene
nodes, colliders, forces, constraints and lights. Everything it owns is added with it and removed with it.
Point and spot lights added to an object move with it.

```ts
/** A lamp circling the scene: a point light and a glowing bulb that move with it. */
class Lamp extends SimObject {
  private angle = 0;

  constructor(color: string) {
    super();
    this.addLight(new PointLight({ x: 0, y: 0, z: 0 }, { color, intensity: 2 }));
    this.addChild(new MeshObject(Mesh.icosphere(0.05, 1), { color, shading: "unlit" }));
  }

  override update(dt: number): void {
    this.angle += dt;
    this.transform.position.x = Math.cos(this.angle) * 2;
    this.transform.position.y = 1;
    this.transform.position.z = Math.sin(this.angle) * 2;
  }
}
sim.add(new Lamp("#ffb26b"));
```

Objects can combine others. Hot data stays in the world's typed arrays, so an object is a handle to many
bodies, never one object per particle:

```ts
/** Shoots droplets up every frame and recycles one once there are `max`. */
class Fountain extends SimObject {
  readonly drops = new ParticleGroup({ radius: 0.02, shading: "lit", color: "#7fb6ff" });

  constructor(private readonly max: number = 400) {
    super();
    this.addChild(this.drops);
  }

  override update(): void {
    const p = this.transform.position;
    const velocity = { x: Math.random() - 0.5, y: 5, z: Math.random() - 0.5 };
    this.drops.add({ position: { x: p.x, y: p.y, z: p.z }, velocity });
    if (this.drops.count > this.max) this.drops.remove(this.drops.idAt(0));
  }
}
```

The hooks: `onAttach(sim)` / `onDetach(sim)` to create and destroy bodies, `update(dt)` every frame before
physics, `fixedUpdate(dt)` every physics step, `sync()` after physics.

### New kinds of 3D objects

When meshes, clouds and lines don't cover it, a `CustomNode` draws itself. Its `emit` runs once per frame and
draws through the same pipeline as everything else: world-space polygons, lines and circles are transformed,
clipped, projected, depth sorted and batched, and `litStyle` shades them with the scene lights.

```ts
/** Draws every rigid body's velocity as a line on top of the scene. */
class VelocityArrows implements CustomNode {
  readonly kind = "custom" as const;
  visible = true;
  layer: number = Layer.Overlay;

  constructor(private readonly world: World) {}

  emit(ctx: EmitContext): void {
    const style = ctx.style(null, "#ffd166", 2);
    const s = this.world.rigid;
    for (let i = 0; i < s.count; i++) {
      const o = i * 3;
      const [x, y, z] = [s.pos[o], s.pos[o + 1], s.pos[o + 2]];
      ctx.line3D(this.layer, style, x, y, z, x + s.vel[o] * 0.2, y + s.vel[o + 1] * 0.2, z + s.vel[o + 2] * 0.2);
    }
  }
}
sim.scene.add(new VelocityArrows(sim.world));
```

`polygon3D` and `line3D` take an optional sort depth as their last argument, for geometry that sorts better as
a whole than by each polygon's own center: a voxel world sorts every face of a block at the block's distance.

### First-person games

`firstPerson` puts `FirstPersonControls` on the canvas: click to capture the pointer, move the mouse to look, Esc
to let go. Where a browser refuses pointer lock (some embedded or automated ones), dragging looks instead. The
camera's position is yours; `forward()` and `right()` give the ground-plane directions to walk in, and
`keyboard.wasPressed()` catches single presses.

```ts
const walker = new Simulation({
  canvas: document.querySelector("canvas")!,
  firstPerson: { sensitivity: 0.003 },
  keyboard: { preventDefault: ["Space"] },
  scene: { background: "#8fbcf0", fog: { color: "#8fbcf0", near: 20, far: 48, mode: "distance" } },
});
const look = walker.firstPerson!;
look.onButton = (button, down) => {
  if (down) console.log(button === 0 ? "break" : "place");
};
walker.onUpdate((dt) => {
  const keys = walker.keyboard!;
  const ahead = keys.axis("KeyS", "KeyW");
  const aside = keys.axis("KeyA", "KeyD");
  const f = look.forward({ x: 0, y: 0, z: 0 });
  const r = look.right({ x: 0, y: 0, z: 0 });
  walker.camera.position.x += (f.x * ahead + r.x * aside) * 4 * dt;
  walker.camera.position.z += (f.z * ahead + r.z * aside) * 4 * dt;
  if (keys.wasPressed("KeyF")) walker.paused = !walker.paused;
});
```

Rigid bodies collide with your own colliders when they implement `rigidShapes`: it is called for every awake
body with a sphere around it, and reports the planes, boxes and spheres there.

```ts
/** Unit blocks wherever `solid` says: rigid bodies land on them like on the built-in colliders. */
class Blocks implements Collider {
  constructor(private readonly solid: (x: number, y: number, z: number) => boolean) {}

  update(): void {}
  solve(): void {} // particles pass through these blocks

  rigidShapes(x: number, y: number, z: number, r: number, out: StaticShapeSink): void {
    for (let by = Math.floor(y - r); by <= Math.floor(y + r); by++) {
      for (let bz = Math.floor(z - r); bz <= Math.floor(z + r); bz++) {
        for (let bx = Math.floor(x - r); bx <= Math.floor(x + r); bx++) {
          if (this.solid(bx, by, bz)) out.box(bx + 0.5, by + 0.5, bz + 0.5, 0.5, 0.5, 0.5);
        }
      }
    }
  }
}
walker.world.addCollider(new Blocks((_x, y) => y < 0));
```

### Running in a worker

`Canvas2DBackend` also draws on an `OffscreenCanvas`, so a whole simulation can run in a worker and leave the
page's main thread free. Input events don't reach a worker: post them from the page. Frames don't get cheaper
this way, since most of a frame is usually the browser filling pixels, but physics-heavy scenes no longer stall
the page.

```ts
// main.ts: hand the canvas to a worker and keep it informed about the size
const view = document.querySelector("canvas")!;
const offscreen = view.transferControlToOffscreen();
const worker = new Worker(new URL("./worker.ts", import.meta.url), { type: "module" });
worker.postMessage({ canvas: offscreen, width: view.clientWidth, height: view.clientHeight, pixelRatio: devicePixelRatio }, [offscreen]);
new ResizeObserver(() => worker.postMessage({ width: view.clientWidth, height: view.clientHeight })).observe(view);

// worker.ts: the simulation, drawing on the transferred canvas
let offscreenBackend: Canvas2DBackend | null = null;
self.onmessage = (e: MessageEvent<{ canvas?: OffscreenCanvas; width: number; height: number; pixelRatio?: number }>) => {
  const { canvas, width, height, pixelRatio } = e.data;
  if (!canvas) {
    offscreenBackend?.setSize(width, height);
    return;
  }
  offscreenBackend = new Canvas2DBackend(canvas, { width, height, pixelRatio });
  const inWorker = new Simulation({ backend: offscreenBackend, orbit: { distance: 4, pitch: -0.3 } });
  inWorker.add(new RigidBox(0.4, { position: { x: 0, y: 2, z: 0 } }));
  inWorker.start();
};
```

### WebGL and textures

`WebGLBackend` draws the same scenes with WebGL2: a depth buffer instead of sorting, lighting per pixel (the
same model as the Canvas 2D backend), and textures. Pass it as the backend; everything else stays the same.
Demo pages switch with `?renderer=webgl`.

```ts
const glCanvas = document.querySelector("canvas")!;
const textured = new Simulation({ canvas: glCanvas, backend: new WebGLBackend(glCanvas) });

/** A 16 x 16 checkerboard, drawn crisp. Any image, bitmap or canvas works as a texture. */
const checker = document.createElement("canvas");
checker.width = checker.height = 16;
const pen = checker.getContext("2d")!;
for (let i = 0; i < 256; i++) {
  pen.fillStyle = ((i % 16) + Math.floor(i / 16)) % 2 ? "#f2c14e" : "#7a3b12";
  pen.fillRect(i % 16, Math.floor(i / 16), 1, 1);
}
// White leaves the texture's colors as they are; the built-in meshes come with UVs
const crate = new MeshObject(Mesh.box(1), { color: "#ffffff", map: new Texture(checker, { filter: "nearest" }) });
textured.add(crate);
```

`Material.map` multiplies its color with the texture; `alphaTest` cuts out pixels (leaves, fences). Your own
meshes take UVs per face corner (`new Mesh(positions, faces, edges, uvs)`). The Canvas 2D backend draws the
material's color instead of the texture.

Custom nodes and planar shadows run through the software pipeline on WebGL too: their screen-space primitives
are drawn at their sort depth, so every `CustomNode` works on both backends. Differences: lines are 1 pixel
wide (WebGL's limit) except those of custom nodes, and "lit" and "sprite" spheres are lit per pixel.

The examples in this README are type-checked in `tests/readmeExamples.ts`.

## Architecture

```
src/
  framework/  Simulation, SimObject and the built-in objects
  math/       vec3 (allocation-free), quat, mat4, Transform, the Vec class
  scene/      PerspectiveCamera, Mesh, Material, lights, Scene and its nodes
  rendering/  RenderBackend, the software pipeline (emit, lighting, shadows, sprites, queue),
              Canvas2DBackend with its rasterizer and sprite cache, WebGLBackend with its shaders
  physics/    World, BodyStore, broadphase, contacts, colliders, forces, constraints, raycasts
    rigid/    rigid body store, shapes, narrowphase, solver pipeline
  controls/   KeyboardState, PointerDrag, OrbitControls, FirstPersonControls
  utility/    PerlinNoise, Random, frame loop
  legacy.ts   the original free functions (project, toScreenCoordinates, rotateAround*)
demos/        each demo: setup.ts (DOM-free content, shared with the benchmarks) and main.ts (page, HUD)
perf/         benchmark scenarios, harness and baselines
tests/        Vitest unit tests and work budgets
```

The low-level API stays public underneath the framework: `world.addBody`, `world.addRigidBody`, `scene.add`,
`world.addForce` and so on, for anything the objects don't cover.

<div align="center">

# 3D Animation

</div>

The basis for the 3D is this perspective formula:

<div align="center">

## $x' = \frac{x}{z}, \quad y' = \frac{y}{z}$

![3D](https://github.com/user-attachments/assets/37327168-5bec-469c-b144-f376c970d03c)

</div>

It is still the core of the renderer. A `PerspectiveCamera` (position, quaternion rotation, field of view)
transforms points into view space, and the projection is `cx + sx * x / z`, `cy - sy * y / z`. With the default
90° field of view the focal length is 1, so the default camera at `z = -1.5` reproduces the original pipeline
exactly (a test checks this). On top of that:

- **Near-plane clipping**: polygons and lines crossing behind the camera are clipped before the divide, so
  orbiting through geometry never produces garbage.
- **One render call per frame** ([#3](https://github.com/ChrisDrae/Projector/issues/3)): objects don't draw
  themselves. They submit primitives to a `RenderQueue`, which sorts them once (back to front in the world
  layer) and draws runs of the same style as a single path with one `fill()`/`stroke()`. The cube demo went
  from a `beginPath`/`fill`/`stroke` per circle and per edge to about 20 draw calls for 1000 spheres. Runs are
  split every `maxBatch` (256) primitives: browsers fill one path of thousands of overlapping shapes
  disproportionately slowly.
- **View culling**: meshes whose bounding sphere lies outside the view are skipped before their vertices are
  transformed, and polygons that land entirely off screen are dropped.
- **Layers**: background, shadows, world (depth sorted) and overlay. Convex meshes can sort as a whole
  (`sortMode: "object"`) so neighbors in a stack never cut into each other.
- **Pluggable backends**: the `RenderBackend` interface takes the scene and camera, so `WebGLBackend` sits next
  to `Canvas2DBackend` without touching scenes or physics (see [WebGL and textures](#webgl-and-textures)).

### Lighting and shading

Canvas 2D has no shaders, depth buffer or per-vertex colors, so lighting is computed in the software pipeline
and baked into fill styles; the canvas only fills. [docs/lighting.md](docs/lighting.md) explains the techniques,
their costs and limits, and what would need WebGL.

- **Lights**: `AmbientLight`, `HemisphereLight`, `DirectionalLight`, `PointLight` and `SpotLight`, all colored.
  Point and spot lights fall off with distance; spot lights have a soft cone edge.
- **Materials**: `shading: "flat" | "smooth" | "unlit"`, Blinn-Phong `specular` and `shininess`, `emissive`.
  Flat faces are lit per face and quantized to shared styles, so they stay batched. Smooth faces are lit per
  corner and filled with canvas gradients.
- **Spheres**: `SphereCloud.shading` / `ParticleGroup({ shading })`: `"flat"` (depth-cued dots), `"lit"` (one
  lit color each) or `"sprite"` (a shaded ball image with a highlight, rendered once and reused; tiny spheres
  fall back to lit dots).
- **Shadows**: lights with `castShadow` project meshes with `castShadow` and sphere clouds onto `receiveShadow`
  planes such as a `Ground`, merged into one draw call per floor.
- **Fog**: `scene.fog = { color, near, far }`, by view depth, or with `mode: "distance"` the same in every
  direction (open landscapes, where depth fog shifts at the edges of the screen as the view turns).
- **Seams**: `new Canvas2DBackend(canvas, { seam: 0.4 })` grows opaque polygons a little, closing the
  anti-aliased hairlines between neighbors drawn in different batches.

<div align="center">

# Particle Animation and Collision

![particles](https://github.com/user-attachments/assets/4c660a08-4b94-4058-b0d3-4bffed4bff41)

# 3D Collision

![combo](https://github.com/user-attachments/assets/f1582f38-8829-4316-8bab-f034e5c665cc)

# Gravitation

![combo](https://github.com/user-attachments/assets/c205217d-c5cf-4506-af08-258bfb359b9f)

</div>

## Physics

- **Structure of arrays** ([#2](https://github.com/ChrisDrae/Projector/issues/2)): particles live in flat
  `Float32Array`s (`pos`, `vel`, `force`, `radius`, `mass`, ...) inside a `BodyStore`, rigid bodies in
  `Float64Array`s inside a `RigidBodyStore`, instead of one object per body. The renderer reads the same arrays
  without copying.
- **Fixed timestep**: `world.step(frameDt)` advances in fixed 1/120 s steps, so the simulation behaves the same at
  any frame rate.
- **Particles**: mass-weighted contact projection and equal and opposite impulses (restitution, friction), so
  momentum is conserved.
- **Rigid bodies**: boxes, spheres and capsules with mass and inertia, static and kinematic bodies. Contacts
  come from a 15-axis separating axis test with face clipping for boxes and closest points for capsules, up to
  four points per pair. A sequential impulse solver with friction, restitution and speculative contacts is warm
  started from the previous step's impulses so stacks rest. Groups of touching bodies that stay still fall
  asleep and wake when touched.
- **Both together**: particles and rigid bodies collide with each other, and both with the colliders.
- **Colliders**: `BoxContainer` (a kinematic box that keeps bodies inside; spinning or moving it throws them
  around), `PlaneCollider`, `SphereCollider`, and your own: `solve()` acts on particles, `rigidShapes()` reports
  planes, boxes and spheres to rigid bodies.
- **Forces and constraints**: gravity, `Drag`, `Attractor`, `VectorField`, `NBodyGravity`, `SpringSet`,
  `DistanceConstraintSet`.
- **Collision groups**: `world.setCollision(groupA, groupB, false)` keeps groups apart (every `ParticleGroup` has
  its own group). Filtering happens after the pair search, so it costs nothing when unused.
- **Picking**: `world.raycast(origin, dir)` and `camera.screenToRay(x, y, ...)`.

## Optimisations

Collision check partitioning was the first big optimisation in this project: instead of checking every circle
against every other, circles are put into grid cells and only check their neighbors. Its failure mode
([#1](https://github.com/ChrisDrae/Projector/issues/1)): when many circles end up in the same cell, it falls back to O(n²).

The `HashGrid` broadphase works on the typed arrays: integer cell hashes and a counting sort, with no string keys
and no allocations per frame. Crowded buckets are handled in one of two modes:

- **accurate** (default): crowded buckets are sorted along x and searched with a binary search plus a sweep
  limited by the largest radius in that bucket. Every overlapping pair is still found.
- **sandbox**: each bucket keeps at most `maxPerCell` bodies and the rest skip body-body collisions for that step
  (rotating, so nobody is left out for long). The cost is bounded no matter what happens.

Bodies also can't collapse into the same cell any more: the solver keeps them apart and the moving box pushes
bodies with its walls instead of teleporting them into a corner. In the cube demo, 4000 spheres dropped on a
single point spread out again within about a second.

## Performance

The framework must not make simulations slower than wiring the parts by hand. Guardrails:

- **Timing baseline**: `perf/scenarios` runs every demo's own setup code headless with scripted input.
  `npm run perf` times physics, emit and raster per frame (median over 600 frames) and samples steady-state
  allocation with V8's heap profiler. It fails when a median is more than 20% slower than `perf/baseline.json`.
  The baselines of the original four demos were recorded on the implementation from before the framework
  existed (tag `perf-baseline`) and are kept as they are; new demos add their own entries.
- **Work budgets** (in `npm test`): deterministic counters per demo (primitives, draw calls, path commands,
  contact pairs, broadphase tests) may not grow more than 10%. They are the same on every machine.
- **Rules**: hot data stays in typed arrays; objects are handles; no per-frame allocation in the step, emit and
  draw paths (the opt-in smooth shading and sprite paths allocate a few KB per frame for canvas gradients and
  new sprites); features cost nothing until used.

Timings depend on the machine and what else runs on it (a demo animating in a browser tab skews them). When in
doubt, compare against the baseline commit directly: check it out in a worktree and run `npm run perf` in both,
back to back.

In the browser, `stats.renderMs` is the CPU side of rendering only: the canvas fills pixels afterwards, often on
the GPU, and in large scenes that is most of the frame. `new Canvas2DBackend(canvas, { syncTiming: true })`
waits for it and includes it, for benchmarking only: it reads a pixel back every frame.

### Further ideas

- Shadow maps on the WebGL backend (shadows are planar on both backends today), and textures on Canvas 2D
- Joints (ball, hinge) and convex hull shapes for rigid bodies
- Glow and bloom with `"lighter"` compositing
- Barnes-Hut for n-body gravity beyond a few thousand bodies
- Physics in a worker of its own with the typed arrays shared, so physics and rendering run in parallel (the
  whole simulation can already move to one, see [Running in a worker](#running-in-a-worker))
